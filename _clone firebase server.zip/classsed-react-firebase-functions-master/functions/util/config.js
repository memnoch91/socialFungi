module.exports = {
  apiKey: 'AIzaSyBGE61bBXSyRfOccvujvR8VjWfB1BjW-Og',
  authDomain: 'socialape-d081e.firebaseapp.com',
  databaseURL: 'https://socialape-d081e.firebaseio.com',
  projectId: 'socialape-d081e',
  storageBucket: 'socialape-d081e.appspot.com',
  messagingSenderId: '354040522108'
};
